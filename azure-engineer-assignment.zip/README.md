# Azure Engineer Assignment – Cost Optimization

## Problem Statement
We have a serverless Azure architecture storing billing records in Cosmos DB. Records older than 3 months are rarely accessed but must be retained. The goal: **reduce cost** while keeping API unchanged, avoiding downtime, and preventing data loss.

## Solution Overview
- Keep recent 90 days of data in Cosmos DB (hot storage).
- Archive older data to Azure Blob Storage (cold storage).
- Use a timer-triggered Azure Function to move old data daily.
- Use an HTTP-triggered Azure Function to fetch from hot or cold storage seamlessly.

## Architecture
![Architecture Diagram](architecture.png)

## Cost Saving Estimate
- **Before:** Cosmos DB storing all data (500 GB) → ~$125/month.
- **After:** Only 90 days in Cosmos DB (~50 GB) + 450 GB in Blob Archive (~$0.002/GB/month) → ~$10/month.
- **Savings:** ~$115/month (~92% reduction in storage costs).

## Deployment
1. Install Azure Functions Core Tools.
2. Set environment variables from `local.settings.json.example`.
3. Run locally:
   ```bash
   func start
   ```
4. Deploy to Azure:
   ```bash
   func azure functionapp publish <YourFunctionAppName>
   ```

## Testing
- **Archive:** Timer trigger runs daily at midnight.
- **Fetch:** `GET /api/billing/{record_id}` → fetches from Cosmos or Blob automatically.

---

**Author:** Vankayala Phani Surya Prapoorna
