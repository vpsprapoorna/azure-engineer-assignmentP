import logging
import azure.functions as func
from azure.cosmos import CosmosClient
from azure.storage.blob import BlobServiceClient
import os
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Processing request to get billing record')
    record_id = req.route_params.get('record_id')
    if not record_id:
        return func.HttpResponse("Record ID is required", status_code=400)

    cosmos_conn = os.getenv("CosmosDBConnectionString")
    blob_conn = os.getenv("BlobStorageConnectionString")
    container_name = os.getenv("BlobContainerName", "billing-archive")

    cosmos_client = CosmosClient.from_connection_string(cosmos_conn)
    database = cosmos_client.get_database_client("BillingDB")
    container = database.get_container_client("BillingRecords")

    try:
        record = container.read_item(item=record_id, partition_key=record_id)
        return func.HttpResponse(json.dumps(record), mimetype="application/json")
    except Exception:
        blob_service_client = BlobServiceClient.from_connection_string(blob_conn)
        blob_container_client = blob_service_client.get_container_client(container_name)
        blob_client = blob_container_client.get_blob_client(f"{record_id}.json")

        if blob_client.exists():
            blob_data = blob_client.download_blob().readall()
            return func.HttpResponse(blob_data, mimetype="application/json")
        else:
            return func.HttpResponse("Record not found", status_code=404)
