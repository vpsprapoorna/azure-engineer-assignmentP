import datetime
import logging
import azure.functions as func
from azure.cosmos import CosmosClient
from azure.storage.blob import BlobServiceClient
import json
import os

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    cosmos_conn = os.getenv("CosmosDBConnectionString")
    blob_conn = os.getenv("BlobStorageConnectionString")
    container_name = os.getenv("BlobContainerName", "billing-archive")

    if not cosmos_conn or not blob_conn:
        logging.error("Missing environment variables for Cosmos DB or Blob Storage")
        return

    client = CosmosClient.from_connection_string(cosmos_conn)
    database = client.get_database_client("BillingDB")
    container = database.get_container_client("BillingRecords")

    blob_service_client = BlobServiceClient.from_connection_string(blob_conn)
    blob_container_client = blob_service_client.get_container_client(container_name)
    blob_container_client.create_container()

    cutoff_date = (datetime.datetime.utcnow() - datetime.timedelta(days=90)).isoformat()
    query = "SELECT * FROM c WHERE c.timestamp < @cutoff"
    items = list(container.query_items(
        query=query,
        parameters=[{"name": "@cutoff", "value": cutoff_date}],
        enable_cross_partition_query=True
    ))

    for item in items:
        blob_name = f"{item['id']}.json"
        blob_client = blob_container_client.get_blob_client(blob_name)
        blob_client.upload_blob(json.dumps(item), overwrite=True)
        container.delete_item(item=item['id'], partition_key=item['partitionKey'])

    logging.info("Archived %d old records to blob storage", len(items))
